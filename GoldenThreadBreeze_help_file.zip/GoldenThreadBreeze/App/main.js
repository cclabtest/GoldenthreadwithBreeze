﻿/* main: startup script creates the 'todo' module */
(function() {

    // app module depends on "Breeze Angular Service"
   // breeze.config.initializeAdapterInstance("modelLibrary", "backingStore");
    angular.module('app', ['breeze.angular']);

})();