﻿/* dataservice: data access and model management layer 
 * relies on Angular injector to provide:
 *     $timeout - Angular equivalent of 'setTimeout'
 *     breeze - the Breeze.Angular service (which is breeze itself)
 *     logger - the application's logging facility
 */
(function () {
    angular.module('app').factory('ApplicationDataService',
    ['$http', '$q', '$timeout', 'breeze', 'logger', dataservice]);

    function dataservice($http, $q, $timeout, breeze, logger) {
        var appkey = "53582A4F-E833-4383-8AC5-EE846A1DE843";
        var serviceName = 'http://graycelltech.net/Goldenthread/api/Application/'; // route to the same origin Web Api controller

        // When data server and application server are in different origins
       
        var ds = new breeze.DataService({
            serviceName: serviceName,
            hasServerMetadata: false
        });
        var manager = new breeze.EntityManager({
            dataService: ds
        });

        var service = {
            GetApplication: GetApplication,
            CreateApplication: CreateApplication

        };
        return service;

        /*** implementation details ***/

        function CreateApplication(application)
        {
            
            var request = $http({
                method: "POST",
                url: serviceName + "Add",
                data: application,
                headers: { "AuthToken": appkey }
            });
            return request
        }

        function GetApplication() {
			var pageSize = 10;
			var pageIndex = 0;
            var ajaxAdapter = breeze.config.getAdapterInstance('ajax');
            ajaxAdapter.defaultSettings = {
                headers: { "AuthToken": appkey },
            };
            var query = breeze.EntityQuery
                .from("Get")				
                .orderBy("ID desc")
				.skip(pageIndex*pageSize)
                .take(pageSize);

            var promise = manager.executeQuery(query).catch(queryFailed);
            return promise;

            function queryFailed(error) {
                alert(error.message);
                return $q.reject(error); // so downstream promise users know it failed
            }
        }


    }


})();